
import Dashboard from './Dashboard';

// Página Index que redireciona para o Dashboard
// Esta é a página padrão quando o usuário acessa a raiz do sistema
const Index = () => {
  return <Dashboard />;
};

export default Index;
